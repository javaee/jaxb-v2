package com.sun.codemodel;

import java.lang.annotation.Annotation;

/**
 * Annotatable program elements.
 *
 * @author Kohsuke Kawaguchi
 */
public interface JAnnotatable {
    /**
     * Adds an annotation to this variable.
     * @param clazz
     *          The annotation class to annotate the field with
     */
    JAnnotationUse annotate(JClass clazz);

    /**
     * Adds an annotation to this variable.
     *
     * @param clazz
     *          The annotation class to annotate the field with
     */
    JAnnotationUse annotate(Class <? extends Annotation> clazz);
}
