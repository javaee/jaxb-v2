package org.javacc;
public interface Version {
   String version = "3.2";
}

