package com.sun.xml.xsom.impl.parser;

import com.sun.xml.xsom.impl.Ref;
import com.sun.xml.xsom.XSContentType;
import com.sun.xml.xsom.XSType;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

public final class BaseContentRef implements Ref.ContentType, Patch {
    private final Ref.Type baseType;
    private final Locator loc;
    private NGCCRuntimeEx runtime;

    public BaseContentRef(NGCCRuntimeEx $runtime, Ref.Type _baseType) {
        this.baseType = _baseType;
        $runtime.addPatcher(this);
        this.loc = $runtime.copyLocator();
        this.runtime = $runtime;
    }

    public XSContentType getContentType() {
        XSType t = baseType.getType();
        if(t.asComplexType()!=null)
            return t.asComplexType().getContentType();
        else
            return t.asSimpleType();
    }

    public void run() throws SAXException {
        if(runtime==null)   return;

        if (baseType instanceof Patch)
            ((Patch) baseType).run();

        XSType t = baseType.getType();
        if (t.isComplexType() && t.asComplexType().getContentType().asParticle()!=null) {
            runtime.reportError(
                Messages.format(Messages.ERR_SIMPLE_CONTENT_EXPECTED,
                    t.getTargetNamespace(), t.getName()), loc);
        }

        runtime = null;
    }
}
