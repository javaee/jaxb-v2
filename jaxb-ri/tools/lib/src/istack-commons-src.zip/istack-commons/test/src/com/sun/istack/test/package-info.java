/**
 * Common test-related utility code for the istack components.
 */
package com.sun.istack.test;
