package com.thaiopensource.datatype.xsd;

interface OrderRelation {
  boolean isLessThan(Object obj1, Object obj2);
}
