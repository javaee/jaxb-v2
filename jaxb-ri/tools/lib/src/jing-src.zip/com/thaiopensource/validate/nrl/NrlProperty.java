package com.thaiopensource.validate.nrl;

import com.thaiopensource.validate.FlagPropertyId;

public class NrlProperty {
  private NrlProperty() { }

  public static final FlagPropertyId ATTRIBUTES_SCHEMA = new FlagPropertyId("ATTRIBUTES_SCHEMA");
}
