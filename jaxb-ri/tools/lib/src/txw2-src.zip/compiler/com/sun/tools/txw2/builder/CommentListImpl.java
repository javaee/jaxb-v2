package com.sun.tools.txw2.builder;

import org.kohsuke.rngom.ast.builder.CommentList;
import org.kohsuke.rngom.ast.util.LocatorImpl;

/**
 * @author Kohsuke Kawaguchi
 */
public interface CommentListImpl extends CommentList<LocatorImpl> {
}
