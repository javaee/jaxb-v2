@XmlNamespace("http://ns/")
package test.t1;

import com.sun.xml.txw2.annotation.XmlNamespace;

