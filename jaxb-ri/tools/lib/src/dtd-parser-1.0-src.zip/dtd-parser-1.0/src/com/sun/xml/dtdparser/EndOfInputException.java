/*
 * @(#)XmlChars.java    1.1 00/08/05
 *
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 */

package com.sun.xml.dtdparser;

import java.io.IOException;

class EndOfInputException extends IOException {
}

