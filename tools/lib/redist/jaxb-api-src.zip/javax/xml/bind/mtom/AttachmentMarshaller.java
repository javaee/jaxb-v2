package javax.xml.bind.mtom;

import javax.activation.DataHandler;
import javax.xml.bind.Marshaller;

/**
 * <p>Enable a MIME-based package processor to optimize storage of binary data.</p>
 * 
 * <p>This API enables an efficient cooperative creation of optimized
 * binary data formats between a JAXB marshalling process and a MIME-based package
 * processor. A JAXB implementation marshals the root body of a MIME-based package, 
 * delegating the creation of referenceable MIME parts to 
 * the MIME-based package processor.</p>
 *
 * @author Marc Hadley
 * @author Kohsuke Kawaguchi
 * @author Joseph Fialli
 * @since JAXB 2.0
 * 
 * @see javax.xml.bind.Marshaller#setAttachmentMarshaller(AttachmentMarshaller)
 */
public abstract class AttachmentMarshaller {

    /**
     * <p>Either add <code>data</code> as an attachment and return attachment's cid
     * or return null to indicate that <code>data</code> must be inlined..
     *
     * <p>
     * This method is called by JAXB marshal process when {@link #isXOPPackage()} is <code>true</code>
     * and for each element whose datatype is "base64Binary", as described in 
     * Step 3 in 
     * <a href="http://www.w3.org/TR/2005/REC-xop10-20050125/#creating_xop_packages">Creating XOP Packages</a>. 
     * The callee determine whether this data shall be attached separately
     * or inlined as base64Binary data. 
     *
     * <p>
     * If the callee wants to optimize the storage of the binary data as a MIME part, 
     * it is responsible for attaching the data to the MIME-based package, and then 
     * assigning an unique content-id, cid, that identifies
     * the MIME part within the MIME message. The callee returns the cid,
     * which enables the JAXB marshaller to marshal a XOP element that refers to that cid in place
     * of marshalling the binary data.
     *
     * <p>
     * Otherwise, the callee can return null, indicating that the <code>data</code> shall
     * be inlined as base64Binary data.
     *
     * <p>
     * The marshal process ensures that if the element containing <code>data</code> has the
     * attribute <code>xmime:contentType</code> or if the JAXB property/field is annotated with a
     * known MIME type, that <code>data.getContentType()</code> must be set to the
     * MIME type.
     *
     * @param elementNamespace
     *      the namespace URI of the element that encloses the base64Binary data.
     *      Can be empty but never null. This information is meant to be used by the callee
     *      to determine whether the data shall be attached or inlined.
     * @param elementLocalName
     *      The local name of the element. Always a non-null valid string.
     * @param data
     *       represents the data to be attached. Must be non-null.
     *        
     * @return
     *     a valid content-id URI, cid, that identifies the attachment containing <code>data</code>.     
     *     Otherwise, null if the attachment was not added and should instead be inlined in the message.
     *  
     * @see <a href="http://www.w3.org/TR/2005/REC-xop10-20050125/">XML-binary Optimized Packaging</a>
     * @see <a href="http://www.w3.org/TR/xml-media-types/">Describing Media Content of Binary Data in XML</a>
     */
    public abstract String addMtomAttachment(String elementNamespace, String elementLocalName, DataHandler data);

    /**
     * <p>Consider optimized storage for binary data represented by <code>data></p>
     *
     * <p>Since content type is not known, the attachment's MIME content 
     * type must be set to "\*\/\*".</p>
     *
     * @return content-id URI, cid, to the attachment containing  
     *         <code>data</code> or null if data should be inlined.
     *
     * @see #addMtomAttachment(String, String, DataHandler)
     */
    public abstract String addMtomAttachment(String elementNamespace, String elementLocalName, byte[] data);

    /**
     * <p>Read-only property that returns true if JAXB marshaller should enable XOP creation.</p>
     *
     * <p>This value must not change during the marshalling process.</p>
     *
     * <p>Marshaller.marshal() must throw IllegalStateException if this value is <code>true</code> 
     * and the XML content to be marshalled violates Step 1 in 
     * http://www.w3.org/TR/2005/REC-xop10-20050125/#creating_xop_packages. 
     * <i>"Ensure the Original XML Infoset contains no element information item with a 
     * [namespace name] of "http://www.w3.org/2004/08/xop/include" and a [local name] of Include"</i>
     *
     * @return true when MIME context is a XOP Package.
     */
    public boolean isXOPPackage() { return false; }

   /**
    * <p>Add <code>data</code> as an attachment and return attachment's content-id, cid.</p>
    * 
    * <p>
    * This method is called by JAXB marshal process for each attribute/element typed as 
    * {http://ws-i.org/profiles/basic/1.1/xsd}swaRef. The callee is responsible for attaching 
    * the specified data to a MIME attachment, and generating a content-id, cid, that 
    * uniquely identifies the attachment within the MIME-based package.
    *
    * <p>The caller will put the returned content-id, cid, into the XML content being marshalled.</p>
    *
    * @param data
    *       represents the data to be attached. Must be non-null. 
    * @return
    *       must be a valid URI used as cid.
    * 
    * @see <a href="http://www.ws-i.org/Profiles/AttachmentsProfile-1.0-2004-08-24.html">WS-I Attachments Profile Version 1.0.</a>
    */
    public abstract String addSwaRefAttachment(DataHandler data);
}

