/**
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.xml.stream;

import javax.xml.stream.XMLOutputFactory ;
import com.sun.xml.stream.writers.*;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.xml.transform.Result;

/**
 * This class provides the implementation of XMLOutputFactory.
 *
 * @author  Neeraj Bajaj,
 * @author k.venugopal@sun.com
 */
public class ZephyrWriterFactory extends XMLOutputFactory{
    
    //List of supported properties and default values.
    private PropertyManager fPropertyManager = null ;
    
    /** Creates a new instance of ZephyrWriterFactory */
    public ZephyrWriterFactory() {
        fPropertyManager = new PropertyManager(PropertyManager.CONTEXT_WRITER);
    }
    
    public javax.xml.stream.XMLEventWriter createXMLEventWriter(javax.xml.transform.Result result) throws javax.xml.stream.XMLStreamException {
        return new XMLEventWriterImpl(createXMLStreamWriter(result));
    }
    
    public javax.xml.stream.XMLEventWriter createXMLEventWriter(java.io.Writer writer) throws javax.xml.stream.XMLStreamException {
        return new XMLEventWriterImpl(createXMLStreamWriter(writer));
    }
    
    public javax.xml.stream.XMLEventWriter createXMLEventWriter(java.io.OutputStream outputStream) throws javax.xml.stream.XMLStreamException {
        return new XMLEventWriterImpl(createXMLStreamWriter(outputStream));
    }
    
    public javax.xml.stream.XMLEventWriter createXMLEventWriter(java.io.OutputStream outputStream, String encoding) throws javax.xml.stream.XMLStreamException {
        return new XMLEventWriterImpl(createXMLStreamWriter(outputStream, encoding));
    }
    
    public javax.xml.stream.XMLStreamWriter createXMLStreamWriter(javax.xml.transform.Result result) throws javax.xml.stream.XMLStreamException {
        if(result instanceof StreamResult){
            StreamResult streamResult = (StreamResult)result;
            if( streamResult.getWriter() != null){
                return new XMLStreamWriterImpl(streamResult.getWriter(), new PropertyManager(fPropertyManager));
            }else if(streamResult.getOutputStream() != null ){
                return new XMLStreamWriterImpl(streamResult.getOutputStream(), new PropertyManager(fPropertyManager));
            }else if(streamResult.getSystemId()!= null){
                try{
                    FileWriter writer = new FileWriter(new File(streamResult.getSystemId()));
                    return new XMLStreamWriterImpl(writer,new PropertyManager(fPropertyManager));
                }catch(IOException ie){
                    throw new XMLStreamException(ie);
                }
            }
        }
        else if(result instanceof Result){
            try{
                //xxx: should we be using FileOutputStream - nb.
                FileWriter writer = new FileWriter(new File(result.getSystemId()));
                return new XMLStreamWriterImpl(writer,new PropertyManager(fPropertyManager));
            }catch(IOException ie){
                throw new XMLStreamException(ie);
            }
        }
        throw new java.lang.UnsupportedOperationException();
    }
    
    public javax.xml.stream.XMLStreamWriter createXMLStreamWriter(java.io.Writer writer) throws javax.xml.stream.XMLStreamException {
        return new XMLStreamWriterImpl(writer, new PropertyManager(fPropertyManager));
    }
    
    public javax.xml.stream.XMLStreamWriter createXMLStreamWriter(java.io.OutputStream outputStream) throws javax.xml.stream.XMLStreamException {
        return new XMLStreamWriterImpl(outputStream, new PropertyManager(fPropertyManager));
    }
    
    public javax.xml.stream.XMLStreamWriter createXMLStreamWriter(java.io.OutputStream outputStream, String encoding) throws javax.xml.stream.XMLStreamException {
        try{
            return new XMLStreamWriterImpl(outputStream, encoding, new PropertyManager(fPropertyManager));
        }catch(Exception ex){
            throw new XMLStreamException(ex);
        }
    }
    
    public Object getProperty(String name) throws java.lang.IllegalArgumentException {
        if(name == null){
            throw new IllegalArgumentException("Property not supported");
        }
        if(fPropertyManager.containsProperty(name))
            return fPropertyManager.getProperty(name);
        throw new IllegalArgumentException("Property not supported");
    }
    
    public boolean isPropertySupported(String name) {
        if(name == null)
            return false ;
        else
            return fPropertyManager.containsProperty(name);
    }
    
    public void setProperty(String name, Object value) throws java.lang.IllegalArgumentException {
        if(name == null || value == null || !fPropertyManager.containsProperty(name) ){
            throw new IllegalArgumentException("Property "+name+"is not supported");
        }
        fPropertyManager.setProperty(name,value);
        
    }
    
}//ZephyrWriterFactory

