package com.sun.msv.datatype.xsd.regex;

import java.text.ParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * {@link RegExpFactory} - official JDK api impl
 *
 * @author Martin Grebac
 */
final class OfficialJDKImpl extends RegExpFactory {

    OfficialJDKImpl() throws Exception {};

    public RegExp compile(String exp) throws ParseException {
       final Pattern p = Pattern.compile(exp);
       return new RegExp() {
            public boolean matches(String text) {
                Matcher m = p.matcher(text);
                return m.matches();
            }
        };
    }

}
