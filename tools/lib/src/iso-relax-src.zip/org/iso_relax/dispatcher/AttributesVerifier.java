package org.iso_relax.dispatcher;

public interface AttributesVerifier {
	// work in progress
}
