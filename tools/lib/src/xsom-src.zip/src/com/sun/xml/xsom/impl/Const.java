/*
 * @(#)$Id: Const.java,v 1.1 2005/04/14 22:06:24 kohsuke Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package com.sun.xml.xsom.impl;

public class Const
{
    /** Namespace URI of XML Schema. */
    public static final String schemaNamespace = "http://www.w3.org/2001/XMLSchema";
}
