/*
 * @(#)$Id: XSListSimpleType.java,v 1.5 2003/09/19 21:55:28 kk122374 Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package com.sun.xml.xsom;

/**
 * List simple type.
 * 
 * @author
 *  Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public interface XSListSimpleType extends XSSimpleType
{
    XSSimpleType getItemType();
}
