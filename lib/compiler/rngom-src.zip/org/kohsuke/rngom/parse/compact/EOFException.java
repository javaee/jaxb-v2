package org.kohsuke.rngom.parse.compact;

import java.io.IOException;

public class EOFException extends IOException {
}
